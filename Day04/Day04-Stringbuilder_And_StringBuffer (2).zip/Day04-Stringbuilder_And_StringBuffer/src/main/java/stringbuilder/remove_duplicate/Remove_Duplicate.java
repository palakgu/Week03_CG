package stringbuilder.remove_duplicate;

import java.util.HashSet;

public class Remove_Duplicate {
    public String void removeDuplicate(String str){
        StringBuilder sb = new StringBuilder();
        HashSet<Character>
    }
}
